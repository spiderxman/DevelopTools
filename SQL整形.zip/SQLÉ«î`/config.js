/* 
 * Copyright 2015 Cosmos Inc. All right reserved.
 * http://www.cos-mos.co.jp/
 */

// ★ = デフォルト（想定外の設定値はデフォルトとして扱う）

// インデント(★1:スペース4、2:タブ) ※Rich Textはスペース4で固定
var configIndent = 1;

// AND/OR/ON位置(1:前1[インデントなし]、2:前2[インデントあり]、★3:後)
var configAndor = 3;

// カンマ位置(1:前、★2:後)
var configComma = 2;

// CASE整形(★1:有効、2:無効)
var configCaseFormat = 1;

// キーワード(★1:変換なし、2:小文字、3:大文字)
var configKeyword = 1;

// 改行コード(★1:CR+LF、2:LF)
var configLineBreak = 1;

// 整形後SQLの末尾(★1:処理なし、2:空白行を付与) ※既に空白行がある場合は付与しない
var configFormatSqlEnd = 1;
